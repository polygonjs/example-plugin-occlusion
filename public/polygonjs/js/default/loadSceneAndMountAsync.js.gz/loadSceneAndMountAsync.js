import{a as r}from"./chunk-FCR7ETNP.js";import"./chunk-YGXD56TG.js";var n=async function(e={}){return e&&e.createViewer==null&&(e.createViewer=!0),r(e)};export{n as loadSceneAndMountAsync_default};
